param(
    [string]$Sdk = $(if ($env:ANDROID_HOME) { $env:ANDROID_HOME } elseif ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' })
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$build = Join-Path $root 'build\manual'
$tools = Join-Path $Sdk 'build-tools\36.0.0'
$platform = Join-Path $Sdk 'platforms\android-36.1\android.jar'
foreach ($required in @($platform, (Join-Path $tools 'aapt2.exe'), (Join-Path $tools 'd8.bat'), (Join-Path $tools 'zipalign.exe'), (Join-Path $tools 'apksigner.bat'))) {
    if (!(Test-Path -LiteralPath $required)) { throw "Missing Android SDK component: $required" }
}
foreach ($folder in @('compiled', 'gen', 'classes', 'dex')) {
    $path = Join-Path $build $folder
    $absolute = [IO.Path]::GetFullPath($path)
    $expectedParent = [IO.Path]::GetFullPath($build).TrimEnd('\') + '\'
    if (!$absolute.StartsWith($expectedParent, [StringComparison]::OrdinalIgnoreCase)) { throw "Unexpected build path: $absolute" }
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    New-Item -ItemType Directory -Path $path -Force | Out-Null
}
$source = Join-Path $root 'app\src\main'
& (Join-Path $tools 'aapt2.exe') compile --dir (Join-Path $source 'res') -o (Join-Path $build 'compiled')
if ($LASTEXITCODE -ne 0) { throw 'Resource compilation failed' }
$flats = @(Get-ChildItem -LiteralPath (Join-Path $build 'compiled') -Filter '*.flat' | ForEach-Object FullName)
& (Join-Path $tools 'aapt2.exe') link -o (Join-Path $build 'resources.apk') --manifest (Join-Path $source 'AndroidManifest.xml') -I $platform --java (Join-Path $build 'gen') --min-sdk-version 29 --target-sdk-version 35 --version-code 3 --version-name 1.2 $flats
if ($LASTEXITCODE -ne 0) { throw 'Resource linking failed' }
$java = @(Get-ChildItem -LiteralPath (Join-Path $source 'java') -Recurse -Filter '*.java' | ForEach-Object FullName)
$java += @(Get-ChildItem -LiteralPath (Join-Path $build 'gen') -Recurse -Filter '*.java' | ForEach-Object FullName)
& javac -encoding UTF-8 -source 17 -target 17 -classpath $platform -d (Join-Path $build 'classes') $java
if ($LASTEXITCODE -ne 0) { throw 'Java compilation failed' }
$classes = @(Get-ChildItem -LiteralPath (Join-Path $build 'classes') -Recurse -Filter '*.class' | ForEach-Object FullName)
& (Join-Path $tools 'd8.bat') --min-api 29 --lib $platform --output (Join-Path $build 'dex') $classes
if ($LASTEXITCODE -ne 0) { throw 'Dex compilation failed' }
$withDex = Join-Path $build 'with-dex.apk'
Copy-Item -LiteralPath (Join-Path $build 'resources.apk') -Destination $withDex -Force
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::Open($withDex, [IO.Compression.ZipArchiveMode]::Update)
try { [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, (Join-Path $build 'dex\classes.dex'), 'classes.dex', [IO.Compression.CompressionLevel]::Optimal) | Out-Null }
finally { $zip.Dispose() }
$aligned = Join-Path $build 'aligned.apk'
& (Join-Path $tools 'zipalign.exe') -f 4 $withDex $aligned
if ($LASTEXITCODE -ne 0) { throw 'APK alignment failed' }
$signing = Join-Path $root '.signing'
New-Item -ItemType Directory -Path $signing -Force | Out-Null
$key = Join-Path $signing 'debug.keystore'
if (!(Test-Path -LiteralPath $key)) {
    & keytool -genkeypair -keystore $key -storepass android -keypass android -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000 -noprompt
    if ($LASTEXITCODE -ne 0) { throw 'Debug key generation failed' }
}
$apk = Join-Path $root 'ScreenRecorder-debug.apk'
& (Join-Path $tools 'apksigner.bat') sign --v4-signing-enabled false --ks $key --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out $apk $aligned
if ($LASTEXITCODE -ne 0) { throw 'APK signing failed' }
& (Join-Path $tools 'apksigner.bat') verify --verbose $apk
if ($LASTEXITCODE -ne 0) { throw 'APK verification failed' }
Write-Output "Built $apk"

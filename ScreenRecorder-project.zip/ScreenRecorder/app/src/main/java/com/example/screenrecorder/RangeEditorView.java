package com.example.screenrecorder;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.function.Consumer;

/** Floating rectangle editor. Coordinates are normalized to the display surface. */
final class RangeEditorView extends View {
    private final Paint paint = new Paint(3);
    private final RectF crop;
    private final Consumer<RectF> save;
    private int gesture;
    private float lastX, lastY;
    private final float density;

    RangeEditorView(Context context, RectF initial, Consumer<RectF> save) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        crop = new RectF(initial);
        this.save = save;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        RectF box = pixels();
        paint.setStyle(Paint.Style.FILL); paint.setColor(0xaa10202c);
        canvas.drawRect(0, 0, w, box.top, paint);
        canvas.drawRect(0, box.top, box.left, box.bottom, paint);
        canvas.drawRect(box.right, box.top, w, box.bottom, paint);
        canvas.drawRect(0, box.bottom, w, h, paint);
        paint.setColor(0xffff944f); paint.setStrokeWidth(dp(3)); paint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(box, paint);
        paint.setStyle(Paint.Style.FILL); paint.setColor(0xffff944f);
        canvas.drawCircle(box.right, box.bottom, dp(14), paint);
        paint.setColor(Color.WHITE); paint.setTextSize(dp(16));
        canvas.drawText("拖曳框移動 · 右下角縮放 · 框外重畫", dp(16), dp(42), paint);
        paint.setColor(0xfffce8c9);
        canvas.drawRoundRect(new RectF(dp(16), h - dp(70), w / 2f - dp(6), h - dp(16)), dp(12), dp(12), paint);
        paint.setColor(0xffe0f0d3);
        canvas.drawRoundRect(new RectF(w / 2f + dp(6), h - dp(70), w - dp(16), h - dp(16)), dp(12), dp(12), paint);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(dp(17)); paint.setColor(0xff183123);
        canvas.drawText("完成", w / 4f, h - dp(35), paint);
        canvas.drawText("全螢幕", w * 3f / 4f, h - dp(35), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX(), y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (y > getHeight() - dp(84)) { gesture = x < getWidth() / 2f ? 4 : 5; return true; }
                RectF box = pixels();
                if (Math.abs(x - box.right) < dp(48) && Math.abs(y - box.bottom) < dp(48)) gesture = 2;
                else if (box.contains(x, y)) gesture = 1;
                else {
                    gesture = 3;
                    float nx = Math.min(0.85f, clamp(x / getWidth()));
                    float ny = Math.min(0.85f, clamp(y / getHeight()));
                    crop.set(nx, ny, nx + 0.15f, ny + 0.15f);
                }
                lastX = x; lastY = y;
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                float dx = (x - lastX) / getWidth(), dy = (y - lastY) / getHeight();
                if (gesture == 1) {
                    float width = crop.width(), height = crop.height();
                    crop.left = Math.max(0, Math.min(1 - width, crop.left + dx));
                    crop.top = Math.max(0, Math.min(1 - height, crop.top + dy));
                    crop.right = crop.left + width; crop.bottom = crop.top + height;
                } else if (gesture == 2 || gesture == 3) {
                    crop.right = Math.max(crop.left + 0.15f, clamp(x / getWidth()));
                    crop.bottom = Math.max(crop.top + 0.15f, clamp(y / getHeight()));
                    crop.right = Math.min(1, crop.right); crop.bottom = Math.min(1, crop.bottom);
                }
                lastX = x; lastY = y; invalidate(); return true;
            case MotionEvent.ACTION_UP:
                if (gesture == 4) save.accept(new RectF(crop));
                else if (gesture == 5) { crop.set(0, 0, 1, 1); save.accept(new RectF(crop)); }
                gesture = 0; return true;
            case MotionEvent.ACTION_CANCEL: gesture = 0; return true;
            default: return true;
        }
    }

    private RectF pixels() {
        return new RectF(crop.left * getWidth(), crop.top * getHeight(), crop.right * getWidth(), crop.bottom * getHeight());
    }
    private float clamp(float n) { return Math.max(0, Math.min(1, n)); }
    private float dp(int n) { return n * density; }
}

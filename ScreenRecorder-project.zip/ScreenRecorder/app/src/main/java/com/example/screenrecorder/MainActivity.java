package com.example.screenrecorder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.media.projection.MediaProjectionManager;
import android.media.projection.MediaProjectionConfig;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ResultReceiver;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 11;
    private static final int NOTIFICATION_REQUEST = 12;
    private static final int FOLDER_REQUEST = 13;
    private static final int AUDIO_REQUEST = 14;
    private static final int BG = 0xfffcfaf3;
    private static final int ORANGE = 0xffff8a3d;
    private static final int GREEN = 0xff8ead80;
    private static final int INK = 0xff17212c;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() { public void run() { updateControls(); handler.postDelayed(this, 500); } };
    private SharedPreferences prefs;
    private Button p720, p1080, record, pause, stop, overlay, folder;
    private Switch highFrame, audio;
    private int selectedResolution;
    private boolean enableOverlayAfterPermission;
    private boolean enterBackgroundAfterPermission;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        prefs = getSharedPreferences("recording", MODE_PRIVATE);
        selectedResolution = prefs.getInt("resolution", 1080);
        buildScreen();
        if (getIntent().getBooleanExtra("request_capture", false)) {
            getIntent().removeExtra("request_capture");
            handler.post(this::requestCapture);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (enableOverlayAfterPermission && Settings.canDrawOverlays(this)) {
            enableOverlayAfterPermission = false;
            command(RecorderService.ENABLE_OVERLAY);
        }
        handler.post(refresh);
    }

    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("request_capture", false)) {
            intent.removeExtra("request_capture");
            handler.post(this::requestCapture);
        }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);
        root.addView(section(4, this::settingsSection));
        root.addView(section(4, this::operationsSection));
        root.addView(section(2, this::bottomSection));
        updateSelection();
        updateControls();
    }

    private interface Content { void fill(LinearLayout layout); }
    private View section(int weight, Content content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        rootSectionParams(scroll, weight);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(20), dp(10), dp(20), dp(8));
        scroll.addView(inner);
        content.fill(inner);
        return scroll;
    }

    private void rootSectionParams(View view, int weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 0, weight);
        view.setLayoutParams(p);
    }

    private void settingsSection(LinearLayout body) {
        title(body, "錄屏設定", "選擇畫質與幀率，取得合適錄製體驗");
        label(body, "解析度", 15, 0xff717579);
        LinearLayout choices = horizontal();
        body.addView(choices, new LinearLayout.LayoutParams(-1, dp(64)));
        p720 = choice("720p", "1280 × 720");
        p1080 = choice("1080p", "1920 × 1080");
        choices.addView(p720, new LinearLayout.LayoutParams(0, -1, 1));
        gap(choices, 8);
        choices.addView(p1080, new LinearLayout.LayoutParams(0, -1, 1));
        p720.setOnClickListener(v -> select(720));
        p1080.setOnClickListener(v -> select(1080));
        LinearLayout mode = horizontal();
        mode.setGravity(Gravity.CENTER_VERTICAL);
        mode.setPadding(dp(12), dp(8), dp(12), dp(8));
        mode.setBackground(shape(0xfff4f7ed, GREEN, 18));
        LinearLayout.LayoutParams modeParams = new LinearLayout.LayoutParams(-1, dp(72));
        modeParams.topMargin = dp(8);
        body.addView(mode, modeParams);
        TextView info = label(null, "120Hz 刷新率錄屏\n最高嘗試 120 fps，依裝置能力調整", 15, INK);
        mode.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        highFrame = new Switch(this);
        highFrame.setChecked(prefs.getBoolean("high_frame", false));
        mode.addView(highFrame);
        TextView caveat = label(body, "高幀率模式不保證影片達到 120 fps。", 12, 0xff747b76);
        caveat.setPadding(0, dp(6), 0, 0);
        LinearLayout sound = horizontal();
        sound.setGravity(Gravity.CENTER_VERTICAL);
        sound.setPadding(dp(12), dp(4), dp(12), dp(4));
        sound.setBackground(shape(0xfff4f7ed, GREEN, 18));
        LinearLayout.LayoutParams soundParams = new LinearLayout.LayoutParams(-1, dp(56));
        soundParams.topMargin = dp(6);
        body.addView(sound, soundParams);
        sound.addView(label(null, "聲音錄製\n手機內部播放聲音（部分 App 不允許擷取）", 13, INK), new LinearLayout.LayoutParams(0, -2, 1));
        audio = new Switch(this);
        audio.setChecked(prefs.getBoolean("audio", false));
        audio.setOnCheckedChangeListener((button, enabled) -> prefs.edit().putBoolean("audio", enabled).apply());
        sound.addView(audio);
    }

    private void operationsSection(LinearLayout body) {
        title(body, "錄屏操作", "通知與小方塊可快速控制錄屏");
        LinearLayout row = horizontal();
        body.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setBackground(shape(0xfff7f8f1, 0xffd9e2d0, 18));
        row.addView(controls, new LinearLayout.LayoutParams(0, -1, 4));
        record = operation(controls, "●  錄影", "通知「開始」／小方塊雙擊");
        pause = operation(controls, "Ⅱ  暫停／繼續", "通知按鈕／小方塊單擊");
        stop = operation(controls, "■  停止", "通知按鈕／小方塊雙擊");
        record.setOnClickListener(v -> requestCapture());
        pause.setOnClickListener(v -> command(RecorderService.TOGGLE_PAUSE));
        stop.setOnClickListener(v -> command(RecorderService.STOP));
        gap(row, 8);
        Button save = new Button(this);
        save.setAllCaps(false);
        save.setText("▣\n儲存");
        save.setTextSize(17);
        save.setTextColor(0xff7b310f);
        save.setBackground(shape(0xffffedd0, ORANGE, 18));
        row.addView(save, new LinearLayout.LayoutParams(0, -1, 1));
        save.setOnClickListener(v -> {
            prefs.edit().putInt("resolution", selectedResolution).putBoolean("high_frame", highFrame.isChecked()).putBoolean("audio", audio.isChecked()).apply();
            Toast.makeText(this, "錄屏設定已儲存", Toast.LENGTH_SHORT).show();
        });
    }

    private void bottomSection(LinearLayout body) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));
        Button background = new Button(this);
        background.setAllCaps(false);
        background.setText("▣\n潛入後台");
        background.setTextSize(18);
        background.setTextColor(0xff174c31);
        background.setBackground(shape(0xffe3efd8, GREEN, 18));
        row.addView(background, new LinearLayout.LayoutParams(0, -1, 1));
        gap(row, 10);
        overlay = new Button(this);
        overlay.setAllCaps(false);
        overlay.setTextSize(18);
        overlay.setTextColor(0xff7b310f);
        overlay.setBackground(shape(0xffffe9cf, ORANGE, 18));
        row.addView(overlay, new LinearLayout.LayoutParams(0, -1, 1));
        background.setOnClickListener(v -> enterBackground());
        overlay.setOnClickListener(v -> toggleOverlay());
        LinearLayout tools = horizontal();
        LinearLayout.LayoutParams toolsParams = new LinearLayout.LayoutParams(-1, dp(48));
        toolsParams.topMargin = dp(8);
        body.addView(tools, toolsParams);
        folder = new Button(this);
        folder.setAllCaps(false);
        folder.setTextSize(13);
        folder.setTextColor(0xff174c31);
        folder.setBackground(shape(0xffeff4e8, GREEN, 14));
        tools.addView(folder, new LinearLayout.LayoutParams(0, -1, 1));
        gap(tools, 6);
        Button pin = new Button(this);
        pin.setAllCaps(false);
        pin.setText("桌面\n圖示");
        pin.setTextSize(12);
        pin.setTextColor(0xff7b310f);
        pin.setBackground(shape(0xffffe9cf, ORANGE, 14));
        tools.addView(pin, new LinearLayout.LayoutParams(dp(60), -1));
        pin.setOnClickListener(v -> pinLauncherShortcut());
        updateFolderLabel();
        folder.setOnClickListener(v -> startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), FOLDER_REQUEST));
        folder.setOnLongClickListener(v -> {
            prefs.edit().remove("folder_uri").remove("folder_name").apply();
            updateFolderLabel();
            Toast.makeText(this, "已恢復預設儲存資料夾", Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private void title(LinearLayout body, String heading, String subtitle) {
        TextView t = label(body, "▏" + heading, 24, INK);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label(body, subtitle, 13, 0xff74777a).setPadding(0, dp(1), 0, dp(9));
    }

    private Button choice(String heading, String sub) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(heading + "\n" + sub);
        b.setTextColor(INK);
        b.setTextSize(17);
        return b;
    }

    private Button operation(LinearLayout parent, String title, String hint) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        b.setPadding(dp(12), dp(3), dp(4), dp(3));
        b.setText(title + "\n" + hint);
        b.setTextSize(13);
        b.setTextColor(INK);
        b.setBackground(shape(0xfff7f8f1, 0xffd9e2d0, 14));
        parent.addView(b, new LinearLayout.LayoutParams(-1, 0, 1));
        return b;
    }

    private TextView label(LinearLayout parent, String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (parent != null) parent.addView(t);
        return t;
    }

    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private void gap(LinearLayout l, int size) { l.addView(new View(this), new LinearLayout.LayoutParams(dp(size), 1)); }
    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void select(int resolution) { selectedResolution = resolution; updateSelection(); }
    private void updateSelection() {
        if (p720 == null || p1080 == null) return;
        boolean is720 = selectedResolution == 720;
        p720.setBackground(shape(is720 ? 0xfffce5c7 : 0xfff2f7ee, is720 ? ORANGE : GREEN, 18));
        p1080.setBackground(shape(is720 ? 0xfff2f7ee : 0xfffce5c7, is720 ? GREEN : ORANGE, 18));
    }
    private void updateControls() {
        if (record == null) return;
        int state = RecorderService.state;
        record.setEnabled(state == RecorderService.IDLE);
        pause.setEnabled(state == RecorderService.RECORDING || state == RecorderService.PAUSED);
        pause.setText(state == RecorderService.PAUSED ? "▶  繼續\n通知按鈕／小方塊單擊" : "Ⅱ  暫停／繼續\n通知按鈕／小方塊單擊");
        stop.setEnabled(state != RecorderService.IDLE);
        overlay.setText(RecorderService.overlayVisible ? "□\n關閉小方塊" : "▣\n錄屏小方塊");
    }

    private void requestCapture() {
        if (RecorderService.state != RecorderService.IDLE) return;
        if (prefs.getBoolean("audio", false) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_REQUEST);
            return;
        }
        MediaProjectionManager manager = getSystemService(MediaProjectionManager.class);
        Intent consent = Build.VERSION.SDK_INT >= 34 && prefs.getBoolean("crop_enabled", false)
            ? manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            : manager.createScreenCaptureIntent();
        startActivityForResult(consent, CAPTURE_REQUEST);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == FOLDER_REQUEST && result == RESULT_OK && data != null && data.getData() != null) {
            Uri tree = data.getData();
            try {
                int grants = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                if ((grants & Intent.FLAG_GRANT_WRITE_URI_PERMISSION) == 0) throw new SecurityException("資料夾沒有寫入權限");
                getContentResolver().takePersistableUriPermission(tree, grants);
                prefs.edit().putString("folder_uri", tree.toString()).putString("folder_name", folderName(tree)).apply();
                updateFolderLabel();
            } catch (RuntimeException e) { Toast.makeText(this, "無法取得資料夾寫入權限", Toast.LENGTH_LONG).show(); }
        }
        if (request == CAPTURE_REQUEST && result == RESULT_OK && data != null) {
            Intent service = new Intent(this, RecorderService.class).setAction(RecorderService.START);
            service.putExtra("result_code", result).putExtra("result_data", data);
            startForegroundService(service);
        }
    }

    private void command(String action) { startService(new Intent(this, RecorderService.class).setAction(action)); }
    private void enterBackground() {
        if (needsNotificationPermission()) { enterBackgroundAfterPermission = true; requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST); return; }
        NotificationManager manager = getSystemService(NotificationManager.class);
        NotificationChannel channel = manager.getNotificationChannel(RecorderService.CHANNEL);
        if (!manager.areNotificationsEnabled() || (channel != null && channel.getImportance() == NotificationManager.IMPORTANCE_NONE)) {
            new AlertDialog.Builder(this).setMessage("錄屏通知已被關閉，請在系統設定中允許通知，才能從通知列控制錄影。")
                .setPositiveButton("開啟通知設定", (dialog, which) -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())))
                .setNegativeButton("取消", null).show();
            return;
        }
        ResultReceiver acknowledgement = new ResultReceiver(handler) {
            @Override protected void onReceiveResult(int code, Bundle result) {
                if (code == 1) moveTaskToBack(true);
                else Toast.makeText(MainActivity.this, "通知控制啟動失敗：" + result.getString("error", "未知錯誤"), Toast.LENGTH_LONG).show();
            }
        };
        try {
            Intent service = new Intent(this, RecorderService.class).setAction(RecorderService.ARM);
            service.putExtra("ack", acknowledgement);
            startForegroundService(service);
        } catch (RuntimeException e) { Toast.makeText(this, "無法啟動後台控制：" + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show(); }
    }
    private void updateFolderLabel() {
        if (folder == null) return;
        String name = prefs.getString("folder_name", null);
        folder.setText(name == null ? "儲存資料夾：Movies/ScreenRecorder　點選指定" : "儲存資料夾：" + name + "　長按還原預設");
    }
    private String folderName(Uri tree) {
        Uri document = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        try (Cursor cursor = getContentResolver().query(document, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (RuntimeException ignored) { }
        return "已選資料夾";
    }
    private void pinLauncherShortcut() {
        ShortcutManager manager = getSystemService(ShortcutManager.class);
        if (manager == null || !manager.isRequestPinShortcutSupported()) {
            Toast.makeText(this, "請從應用程式清單長按「淡橘錄屏」並加入桌面", Toast.LENGTH_LONG).show();
            return;
        }
        Intent launch = new Intent(this, MainActivity.class).setAction(Intent.ACTION_MAIN)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        ShortcutInfo shortcut = new ShortcutInfo.Builder(this, "launch_screen_recorder")
            .setShortLabel("淡橘錄屏")
            .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
            .setIntent(launch)
            .build();
        if (!manager.requestPinShortcut(shortcut, null))
            Toast.makeText(this, "桌面圖示建立失敗，請從應用程式清單加入", Toast.LENGTH_LONG).show();
    }
    private boolean needsNotificationPermission() {
        return Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED;
    }
    private void toggleOverlay() {
        if (RecorderService.overlayVisible) { command(RecorderService.DISABLE_OVERLAY); return; }
        if (!Settings.canDrawOverlays(this)) {
            enableOverlayAfterPermission = true;
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        if (needsNotificationPermission()) { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST); }
        startForegroundService(new Intent(this, RecorderService.class).setAction(RecorderService.ENABLE_OVERLAY));
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request == AUDIO_REQUEST) {
            if (grants.length > 0 && grants[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) requestCapture();
            else Toast.makeText(this, "請允許錄音權限，才能擷取手機內部聲音", Toast.LENGTH_LONG).show();
            return;
        }
        if (request == NOTIFICATION_REQUEST && enterBackgroundAfterPermission) {
            enterBackgroundAfterPermission = false;
            if (grants.length > 0 && grants[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) enterBackground();
            else Toast.makeText(this, "請允許通知，才能在後台使用通知控制", Toast.LENGTH_LONG).show();
        }
    }
}

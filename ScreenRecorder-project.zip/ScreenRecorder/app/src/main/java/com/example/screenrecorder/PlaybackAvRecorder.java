package com.example.screenrecorder;

import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.graphics.RectF;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.os.SystemClock;
import android.view.Surface;
import java.io.FileDescriptor;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Encodes a projection surface and permitted app playback into one MP4. */
final class PlaybackAvRecorder {
    private static final int SAMPLE_RATE = 48000;
    private static final int AUDIO_BYTES = 4096;
    private final FileDescriptor output;
    private final int width, height, fps, bitRate, density;
    private final Consumer<String> failure;
    private final List<Sample> pending = new ArrayList<>();
    private MediaCodec video, audio;
    private Surface surface;
    private AudioRecord capture;
    private MediaMuxer muxer;
    private VirtualDisplay display;
    private CropSurfacePipeline cropPipeline;
    private Thread worker;
    private volatile boolean running, paused;
    private volatile long pausedUs;
    private long pauseStartedNs;
    private long audioFrames, videoBaseUs = -1, lastVideoUs = -1, lastAudioUs = -1;
    private volatile int audioPeak;
    private int videoTrack = -1, audioTrack = -1;
    private boolean muxerStarted, videoSampleWritten, videoEnded, audioEnded;
    private volatile String workerFailure;

    PlaybackAvRecorder(FileDescriptor output, int width, int height, int fps, int bitRate, int density, Consumer<String> failure) {
        this.output = output; this.width = width; this.height = height; this.fps = fps;
        this.bitRate = bitRate; this.density = density; this.failure = failure;
    }

    void start(MediaProjection projection, RectF crop, int sourceWidth, int sourceHeight) throws IOException {
        try {
            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, bitRate);
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            video = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            video.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface = video.createInputSurface();

            MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 1);
            audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 128000);
            audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            audio = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            audio.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);

            AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build();
            AudioFormat pcm = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build();
            int minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            capture = new AudioRecord.Builder().setAudioFormat(pcm)
                .setAudioPlaybackCaptureConfig(config).setBufferSizeInBytes(Math.max(16384, minBuffer * 2)).build();
            if (capture.getState() != AudioRecord.STATE_INITIALIZED) throw new IOException("內部聲音擷取無法初始化");
            muxer = new MediaMuxer(output, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            video.start(); audio.start(); capture.startRecording();
            if (capture.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IOException("內部聲音擷取無法啟動");
            running = true;
            worker = new Thread(this::encodeLoop, "screen-av-encoder");
            worker.start();
            if (crop == null) {
                display = projection.createVirtualDisplay("淡橘錄屏", width, height, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null);
            } else {
                cropPipeline = new CropSurfacePipeline(surface, sourceWidth, sourceHeight,
                    width, height, crop, failure);
                cropPipeline.start(projection, density);
            }
        } catch (Exception e) {
            running = false;
            if (capture != null && capture.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                try { capture.stop(); } catch (RuntimeException ignored) { }
            }
            if (worker != null) {
                try { worker.join(2000); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            }
            release();
            if (e instanceof IOException) throw (IOException)e;
            throw new IOException("影音編碼初始化失敗", e);
        }
    }

    void pause() {
        if (paused) return;
        paused = true;
        pauseStartedNs = SystemClock.elapsedRealtimeNanos();
        if (cropPipeline != null) cropPipeline.pause();
        else if (display != null) display.setSurface(null);
        if (capture != null) capture.stop();
    }

    void resume() {
        if (!paused) return;
        pausedUs += (SystemClock.elapsedRealtimeNanos() - pauseStartedNs) / 1000;
        capture.startRecording();
        if (capture.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("聲音擷取無法繼續");
        if (cropPipeline != null) cropPipeline.resume();
        else if (display != null) display.setSurface(surface);
        paused = false;
    }

    boolean stop() {
        running = false;
        if (cropPipeline != null) { cropPipeline.stop(); cropPipeline = null; }
        if (display != null) { try { display.release(); } catch (RuntimeException ignored) { } display = null; }
        if (capture != null && capture.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
            try { capture.stop(); } catch (RuntimeException ignored) { }
        }
        if (worker != null) {
            try { worker.join(5000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            if (worker.isAlive()) workerFailure = "編碼器未及時結束";
        }
        boolean success = workerFailure == null && muxerStarted && videoSampleWritten;
        if (muxerStarted) { try { muxer.stop(); } catch (RuntimeException e) { success = false; } }
        release();
        return success;
    }

    private void encodeLoop() {
        try {
            long start = SystemClock.elapsedRealtime();
            byte[] pcm = new byte[AUDIO_BYTES];
            while (running) {
                if (!paused) {
                    int n = capture.read(pcm, 0, pcm.length, AudioRecord.READ_NON_BLOCKING);
                    if (n < 0) throw new IOException("內部音訊讀取失敗：" + n);
                    if (n > 0) {
                        for (int i = 0; i + 1 < n; i += 2) {
                            int value = (short)(((pcm[i + 1] & 0xff) << 8) | (pcm[i] & 0xff));
                            audioPeak = Math.max(audioPeak, Math.abs(value));
                        }
                        queueAudio(pcm, n);
                    }
                }
                drain(video, true);
                drain(audio, false);
                if (!muxerStarted && SystemClock.elapsedRealtime() - start > 5000) throw new IOException("影音軌道建立逾時");
                Thread.sleep(5);
            }
            video.signalEndOfInputStream();
            queueAudioEnd();
            long end = SystemClock.elapsedRealtime() + 3000;
            while ((!videoEnded || !audioEnded) && SystemClock.elapsedRealtime() < end) {
                drain(video, true); drain(audio, false);
                Thread.sleep(2);
            }
            if (!videoEnded || !audioEnded) throw new IOException("影音編碼未完整結束");
        } catch (Exception e) {
            workerFailure = e.getClass().getSimpleName() + ": " + e.getMessage();
            if (running) failure.accept(workerFailure);
        }
    }

    private void queueAudio(byte[] pcm, int length) {
        int index = audio.dequeueInputBuffer(0);
        if (index < 0) return;
        ByteBuffer input = audio.getInputBuffer(index);
        if (input == null) return;
        int size = Math.min(length, input.capacity()) & ~1;
        input.clear(); input.put(pcm, 0, size);
        long pts = audioFrames * 1000000L / SAMPLE_RATE;
        audioFrames += size / 2L;
        audio.queueInputBuffer(index, 0, size, pts, 0);
    }

    private void queueAudioEnd() {
        for (int attempt = 0; attempt < 100; attempt++) {
            int index = audio.dequeueInputBuffer(10000);
            if (index >= 0) {
                audio.queueInputBuffer(index, 0, 0, audioFrames * 1000000L / SAMPLE_RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                return;
            }
            drain(audio, false);
        }
        throw new IllegalStateException("音訊編碼器無法結束");
    }

    private void drain(MediaCodec codec, boolean isVideo) {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (true) {
            int index = codec.dequeueOutputBuffer(info, 0);
            if (index == MediaCodec.INFO_TRY_AGAIN_LATER) return;
            if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (isVideo) videoTrack = muxer.addTrack(codec.getOutputFormat());
                else audioTrack = muxer.addTrack(codec.getOutputFormat());
                if (videoTrack >= 0 && audioTrack >= 0 && !muxerStarted) {
                    muxer.start(); muxerStarted = true;
                    for (Sample sample : pending) write(sample);
                    pending.clear();
                }
                continue;
            }
            if (index < 0) continue;
            if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                if (isVideo) videoEnded = true; else audioEnded = true;
            }
            if (info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                ByteBuffer encoded = codec.getOutputBuffer(index);
                if (encoded != null) {
                    encoded.position(info.offset); encoded.limit(info.offset + info.size);
                    byte[] data = new byte[info.size]; encoded.get(data);
                    long pts = info.presentationTimeUs;
                    if (isVideo) {
                        if (videoBaseUs < 0) videoBaseUs = pts;
                        pts = Math.max(lastVideoUs + 1, pts - videoBaseUs - pausedUs);
                        lastVideoUs = pts;
                    } else { pts = Math.max(lastAudioUs + 1, pts); lastAudioUs = pts; }
                    Sample sample = new Sample(isVideo, data, pts, info.flags);
                    if (muxerStarted) write(sample);
                    else {
                        if (pending.size() >= 300) throw new IllegalStateException("影音軌道緩衝已滿");
                        pending.add(sample);
                    }
                }
            }
            codec.releaseOutputBuffer(index, false);
        }
    }

    private void write(Sample sample) {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        info.set(0, sample.data.length, sample.pts, sample.flags & ~MediaCodec.BUFFER_FLAG_END_OF_STREAM);
        muxer.writeSampleData(sample.video ? videoTrack : audioTrack, ByteBuffer.wrap(sample.data), info);
        if (sample.video) videoSampleWritten = true;
    }

    private void release() {
        if (cropPipeline != null) { cropPipeline.stop(); cropPipeline = null; }
        if (display != null) { try { display.release(); } catch (RuntimeException ignored) { } display = null; }
        if (capture != null) { try { capture.release(); } catch (RuntimeException ignored) { } capture = null; }
        if (video != null) { try { video.stop(); } catch (RuntimeException ignored) { } try { video.release(); } catch (RuntimeException ignored) { } video = null; }
        if (audio != null) { try { audio.stop(); } catch (RuntimeException ignored) { } try { audio.release(); } catch (RuntimeException ignored) { } audio = null; }
        if (surface != null) { surface.release(); surface = null; }
        if (muxer != null) { try { muxer.release(); } catch (RuntimeException ignored) { } muxer = null; }
    }

    String soundWarning() {
        if (audioFrames == 0) return "影片沒有取得內部音訊資料；請檢查錄音權限";
        if (audioPeak < 128) return "內部音軌為靜音；播放影片的 App 可能不允許擷取聲音";
        return null;
    }

    private static final class Sample {
        final boolean video;
        final byte[] data;
        final long pts;
        final int flags;
        Sample(boolean video, byte[] data, long pts, int flags) {
            this.video = video; this.data = data; this.pts = pts; this.flags = flags;
        }
    }
}

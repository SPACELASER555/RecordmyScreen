package com.example.screenrecorder;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.graphics.drawable.Icon;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    public static final String ARM = "arm", START = "start", STOP = "stop";
    public static final String TOGGLE_PAUSE = "toggle_pause", ENABLE_OVERLAY = "enable_overlay", DISABLE_OVERLAY = "disable_overlay";
    public static final int IDLE = 0, RECORDING = 1, PAUSED = 2;
    public static volatile int state = IDLE;
    public static volatile boolean overlayVisible = false;
    public static final String CHANNEL = "recording_controls_v2";
    private static final int NOTIFICATION_ID = 100;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaRecorder recorder;
    private PlaybackAvRecorder playbackRecorder;
    private CropSurfacePipeline cropPipeline;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ParcelFileDescriptor file;
    private Uri output;
    private boolean mediaStoreOutput;
    private String outputLocation;
    private boolean armed;
    private boolean stopping;
    private WindowManager windows;
    private WindowManager.LayoutParams overlayParams;
    private View overlay;
    private View rangeButton;
    private View rangeEditor;
    private WindowManager.LayoutParams rangeParams;
    private TextView overlayText;
    private long lastTap;
    private Runnable pendingSingle;
    private Runnable pendingLong;
    private boolean dragging;
    private boolean longTriggered;
    private float dragX, dragY;
    private int initialX, initialY;

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel(CHANNEL, "錄屏控制", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("錄屏開始、暫停與停止");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
        windows = getSystemService(WindowManager.class);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ARM.equals(action)) {
            ResultReceiver ack = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra("ack", ResultReceiver.class) : intent.getParcelableExtra("ack");
            try {
                armed = true;
                showForeground(false);
                if (ack != null) ack.send(1, new Bundle());
            } catch (RuntimeException e) {
                armed = false;
                if (ack != null) {
                    Bundle error = new Bundle(); error.putString("error", e.getClass().getSimpleName());
                    ack.send(-1, error);
                }
                stopSelf();
                return START_NOT_STICKY;
            }
        } else if (ENABLE_OVERLAY.equals(action)) {
            armed = true;
            showForeground(false);
            addOverlay();
        } else if (DISABLE_OVERLAY.equals(action)) {
            removeOverlay();
            settleIdleService();
        } else if (START.equals(action)) {
            if (state == IDLE) {
                armed = true;
                try { showForeground(true); }
                catch (RuntimeException e) {
                    armed = false;
                    showError("錄屏服務無法啟動：" + e.getClass().getSimpleName());
                    stopSelf();
                    return START_NOT_STICKY;
                }
                Intent consent = Build.VERSION.SDK_INT >= 33
                    ? intent.getParcelableExtra("result_data", Intent.class)
                    : intent.getParcelableExtra("result_data");
                if (consent != null && intent.getIntExtra("result_code", Activity.RESULT_CANCELED) == Activity.RESULT_OK) {
                    startCapture(consent);
                } else { showError("錄屏授權已取消"); settleIdleService(); }
            }
        } else if (TOGGLE_PAUSE.equals(action)) {
            togglePause();
        } else if (STOP.equals(action)) {
            stopCapture(true);
        }
        if (armed || overlay != null || state != IDLE) updateNotification();
        updateOverlay();
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void showForeground(boolean capture) {
        if (Build.VERSION.SDK_INT >= 34) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            if (capture) {
                type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if (getSharedPreferences("recording", MODE_PRIVATE).getBoolean("audio", false)) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            startForeground(NOTIFICATION_ID, notification(), type);
        } else if (capture) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            if (Build.VERSION.SDK_INT >= 30 && getSharedPreferences("recording", MODE_PRIVATE).getBoolean("audio", false)) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            startForeground(NOTIFICATION_ID, notification(), type);
        } else startForeground(NOTIFICATION_ID, notification());
    }

    private Notification notification() {
        boolean sound = getSharedPreferences("recording", MODE_PRIVATE).getBoolean("audio", false);
        String line = state == RECORDING ? (sound ? "正在錄影 · 內部聲音開啟" : "正在錄影 · 無聲")
            : state == PAUSED ? "錄影已暫停" : "點選「開始」取得系統錄屏授權";
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.notification_icon)
            .setContentTitle("淡橘錄屏")
            .setContentText(line)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setPriority(Notification.PRIORITY_HIGH)
            .setContentIntent(captureActivity(false));
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        Icon icon = Icon.createWithResource(this, R.drawable.notification_icon);
        if (state == IDLE) b.addAction(new Notification.Action.Builder(icon, "開始", captureActivity(true)).build());
        else {
            b.addAction(new Notification.Action.Builder(icon, state == PAUSED ? "繼續" : "暫停", commandIntent(TOGGLE_PAUSE, 2)).build());
            b.addAction(new Notification.Action.Builder(icon, "停止", commandIntent(STOP, 3)).build());
        }
        return b.build();
    }

    private PendingIntent captureActivity(boolean requestCapture) {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (requestCapture) i.putExtra("request_capture", true);
        return PendingIntent.getActivity(this, requestCapture ? 1 : 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private PendingIntent commandIntent(String command, int code) {
        Intent i = new Intent(this, RecorderService.class).setAction(command);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, notification());
    }

    private void startCapture(Intent consent) {
        try {
            int target = getSharedPreferences("recording", MODE_PRIVATE).getInt("resolution", 1080);
            boolean high = getSharedPreferences("recording", MODE_PRIVATE).getBoolean("high_frame", false);
            int screenWidth, screenHeight;
            if (Build.VERSION.SDK_INT >= 30) {
                Rect bounds = windows.getMaximumWindowMetrics().getBounds();
                screenWidth = bounds.width(); screenHeight = bounds.height();
            } else {
                Point bounds = new Point();
                windows.getDefaultDisplay().getRealSize(bounds);
                screenWidth = bounds.x; screenHeight = bounds.y;
            }
            RectF crop = selectedCrop();
            int captureWidth = crop == null ? screenWidth : Math.max(2, Math.round(screenWidth * crop.width()));
            int captureHeight = crop == null ? screenHeight : Math.max(2, Math.round(screenHeight * crop.height()));
            int longSide = target == 720 ? 1280 : 1920;
            double scale = Math.min(1.0, (double) longSide / Math.max(captureWidth, captureHeight));
            int width = even((int)(captureWidth * scale));
            int height = even((int)(captureHeight * scale));
            int fps = selectFrameRate(width, height, high);
            createOutput();
            boolean sound = getSharedPreferences("recording", MODE_PRIVATE).getBoolean("audio", false);
            if (sound) {
                createProjection(consent);
                playbackRecorder = new PlaybackAvRecorder(file.getFileDescriptor(), width, height, fps,
                    Math.min(25000000, Math.max(3000000, width * height * fps / 9)),
                    getResources().getConfiguration().densityDpi,
                    error -> handler.post(() -> { showError("影音編碼失敗：" + error); stopCapture(false); }));
                playbackRecorder.start(projection, crop, screenWidth, screenHeight);
                state = RECORDING;
                return;
            }
            recorder = new MediaRecorder();
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(width, height);
            recorder.setVideoFrameRate(fps);
            recorder.setVideoEncodingBitRate(Math.min(25000000, Math.max(3000000, width * height * fps / 9)));
            recorder.setOutputFile(file.getFileDescriptor());
            recorder.prepare();

            createProjection(consent);
            if (crop == null) {
                display = projection.createVirtualDisplay("淡橘錄屏", width, height,
                    getResources().getConfiguration().densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    recorder.getSurface(), null, handler);
                recorder.start();
                state = RECORDING;
            } else {
                recorder.start(); state = RECORDING;
                cropPipeline = new CropSurfacePipeline(recorder.getSurface(), screenWidth, screenHeight,
                    width, height, crop, error -> handler.post(() -> { showError(error); stopCapture(false); }));
                cropPipeline.start(projection, getResources().getConfiguration().densityDpi);
            }
        } catch (Exception e) {
            showError("錄影無法開始：" + e.getClass().getSimpleName());
            stopCapture(false);
        }
    }

    private void createProjection(Intent consent) {
        projection = getSystemService(MediaProjectionManager.class).getMediaProjection(Activity.RESULT_OK, consent);
        if (projection == null) throw new IllegalStateException("系統未提供錄屏工作階段");
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { handler.post(() -> stopCapture(true)); }
            @Override public void onCapturedContentResize(int width, int height) {
                // MP4 encoder size remains fixed during this recording.
            }
        }, handler);
    }

    private int even(int value) { return Math.max(2, value & ~1); }
    private RectF selectedCrop() {
        android.content.SharedPreferences prefs = getSharedPreferences("recording", MODE_PRIVATE);
        if (!prefs.getBoolean("crop_enabled", false)) return null;
        float left = prefs.getFloat("crop_left", 0), top = prefs.getFloat("crop_top", 0);
        float right = prefs.getFloat("crop_right", 1), bottom = prefs.getFloat("crop_bottom", 1);
        if (left < 0 || top < 0 || right > 1 || bottom > 1 || right - left < 0.15f || bottom - top < 0.15f) return null;
        return new RectF(left, top, right, bottom);
    }
    private int selectFrameRate(int width, int height, boolean high) {
        int[] choices = high ? new int[]{120, 90, 60, 30} : new int[]{30};
        for (int fps : choices) {
            for (MediaCodecInfo codec : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
                if (!codec.isEncoder()) continue;
                try {
                    MediaCodecInfo.CodecCapabilities caps = codec.getCapabilitiesForType("video/avc");
                    if (caps.getVideoCapabilities().areSizeAndRateSupported(width, height, fps)) return fps;
                } catch (IllegalArgumentException ignored) { }
            }
        }
        return 30;
    }

    private void createOutput() throws IOException {
        String name = "ScreenRecording_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        String folder = getSharedPreferences("recording", MODE_PRIVATE).getString("folder_uri", null);
        if (folder != null) {
            Uri tree = Uri.parse(folder);
            Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
            output = DocumentsContract.createDocument(getContentResolver(), parent, "video/mp4", name);
            mediaStoreOutput = false;
            outputLocation = getSharedPreferences("recording", MODE_PRIVATE).getString("folder_name", "已選資料夾");
            if (output == null) throw new IOException("無法在選定資料夾建立影片");
            file = getContentResolver().openFileDescriptor(output, "w");
            if (file == null) throw new IOException("無法開啟選定資料夾的影片");
            return;
        }
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ScreenRecorder");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        output = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        mediaStoreOutput = true;
        outputLocation = "Movies/ScreenRecorder";
        if (output == null) throw new IOException("無法建立影片");
        file = getContentResolver().openFileDescriptor(output, "w");
        if (file == null) throw new IOException("無法開啟影片");
    }

    private void togglePause() {
        try {
            if (state == RECORDING) {
                if (playbackRecorder != null) playbackRecorder.pause();
                else { if (cropPipeline != null) cropPipeline.pause(); recorder.pause(); }
                state = PAUSED;
            } else if (state == PAUSED) {
                if (playbackRecorder != null) playbackRecorder.resume();
                else { recorder.resume(); if (cropPipeline != null) cropPipeline.resume(); }
                state = RECORDING;
            }
        } catch (RuntimeException e) { showError("暫停／繼續失敗"); stopCapture(false); }
    }

    private void stopCapture(boolean save) {
        if (stopping) return;
        stopping = true;
        boolean completed = false;
        String soundWarning = null;
        try {
            if (cropPipeline != null) { cropPipeline.stop(); cropPipeline = null; }
            if (playbackRecorder != null) {
                try {
                    completed = playbackRecorder.stop() && save;
                    soundWarning = playbackRecorder.soundWarning();
                }
                catch (RuntimeException e) { showError("影音檔案無法完成"); }
                playbackRecorder = null;
            }
            if (display != null) {
                try { display.release(); } catch (RuntimeException ignored) { }
                display = null;
            }
            if (recorder != null) {
                if (state != IDLE) {
                    try { recorder.stop(); completed = save; }
                    catch (RuntimeException ignored) { showError("影片太短或錄影中斷，未儲存"); }
                }
                try { recorder.reset(); } catch (RuntimeException ignored) { }
                try { recorder.release(); } catch (RuntimeException ignored) { }
                recorder = null;
            }
            if (projection != null) {
                MediaProjection old = projection; projection = null;
                try { old.stop(); } catch (RuntimeException ignored) { }
            }
            if (file != null) {
                try { file.close(); } catch (IOException ignored) { }
                file = null;
            }
            if (output != null) {
                try {
                    if (completed) {
                        if (mediaStoreOutput) {
                            ContentValues update = new ContentValues(); update.put(MediaStore.Video.Media.IS_PENDING, 0);
                            getContentResolver().update(output, update, null, null);
                        }
                        Toast.makeText(this, "影片已儲存至 " + outputLocation
                            + (soundWarning == null ? "" : "\n" + soundWarning), Toast.LENGTH_LONG).show();
                    } else if (mediaStoreOutput) getContentResolver().delete(output, null, null);
                    else DocumentsContract.deleteDocument(getContentResolver(), output);
                } catch (Exception e) { showError("影片儲存狀態更新失敗"); }
                output = null;
            }
        } finally {
            state = IDLE; stopping = false;
            if (armed || overlay != null) { showForeground(false); updateNotification(); }
            else settleIdleService();
            updateOverlay();
        }
    }

    private void settleIdleService() {
        if (state == IDLE && !armed && overlay == null) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    }

    private void addOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        overlayText = new TextView(this);
        overlayText.setTextSize(26);
        overlayText.setGravity(Gravity.CENTER);
        overlayText.setTextColor(0xff72300c);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(0xffffdfb5); shape.setCornerRadius(dp(14)); shape.setStroke(dp(2), 0xffff8a3d);
        overlayText.setBackground(shape);
        overlayText.setElevation(dp(8));
        overlayText.setOnTouchListener(this::handleTouch);
        overlay = overlayText;
        overlayParams = new WindowManager.LayoutParams(dp(58), dp(58), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = dp(15); overlayParams.y = dp(140);
        try { windows.addView(overlay, overlayParams); overlayVisible = true; updateOverlay(); }
        catch (RuntimeException e) { overlay = null; overlayText = null; overlayVisible = false; showError("小方塊無法顯示"); }
        if (overlay != null) {
            TextView edit = new TextView(this);
            edit.setText("範圍"); edit.setTextSize(13); edit.setGravity(Gravity.CENTER);
            edit.setTextColor(0xff174c31);
            GradientDrawable green = new GradientDrawable();
            green.setColor(0xffe3efd8); green.setCornerRadius(dp(12)); green.setStroke(dp(2), 0xff8ead80);
            edit.setBackground(green);
            edit.setOnClickListener(v -> showRangeEditor());
            rangeParams = new WindowManager.LayoutParams(dp(52), dp(58), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            rangeParams.gravity = Gravity.TOP | Gravity.START;
            rangeParams.x = overlayParams.x + dp(64); rangeParams.y = overlayParams.y;
            try { windows.addView(edit, rangeParams); rangeButton = edit; }
            catch (RuntimeException e) { showError("錄製範圍按鈕無法顯示"); }
        }
    }

    private void showRangeEditor() {
        if (state != IDLE) { showError("請先停止錄影，再調整下一段的錄製範圍"); return; }
        if (rangeEditor != null) return;
        android.content.SharedPreferences prefs = getSharedPreferences("recording", MODE_PRIVATE);
        RectF initial = prefs.getBoolean("crop_enabled", false)
            ? new RectF(prefs.getFloat("crop_left", 0), prefs.getFloat("crop_top", 0),
                prefs.getFloat("crop_right", 1), prefs.getFloat("crop_bottom", 1))
            : new RectF(0.15f, 0.15f, 0.85f, 0.82f);
        RangeEditorView view = new RangeEditorView(this, initial, rect -> {
            boolean full = rect.left < 0.01f && rect.top < 0.01f && rect.right > 0.99f && rect.bottom > 0.99f;
            prefs.edit().putBoolean("crop_enabled", !full)
                .putFloat("crop_left", rect.left).putFloat("crop_top", rect.top)
                .putFloat("crop_right", rect.right).putFloat("crop_bottom", rect.bottom).apply();
            closeRangeEditor();
            Toast.makeText(this, full ? "下一段錄製整個螢幕" : "下一段將只錄製框選範圍", Toast.LENGTH_SHORT).show();
        });
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        try { windows.addView(view, params); rangeEditor = view; }
        catch (RuntimeException e) { showError("範圍選擇器無法顯示"); }
    }
    private void closeRangeEditor() {
        if (rangeEditor != null) { try { windows.removeView(rangeEditor); } catch (RuntimeException ignored) { } rangeEditor = null; }
    }

    private boolean handleTouch(View view, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = false;
                longTriggered = false;
                pendingLong = () -> { longTriggered = true; removeOverlay(); updateNotification(); };
                handler.postDelayed(pendingLong, 3000);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (event.getPointerCount() >= 2) {
                    cancelLong(); cancelSingle(); dragging = true;
                    dragX = (event.getRawX() + event.getRawX(1)) / 2f;
                    dragY = (event.getRawY() + event.getRawY(1)) / 2f;
                    initialX = overlayParams.x; initialY = overlayParams.y;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging && event.getPointerCount() >= 2 && overlay != null) {
                    overlayParams.x = Math.max(0, initialX + Math.round((event.getRawX() + event.getRawX(1)) / 2f - dragX));
                    overlayParams.y = Math.max(0, initialY + Math.round((event.getRawY() + event.getRawY(1)) / 2f - dragY));
                    windows.updateViewLayout(overlay, overlayParams);
                    if (rangeButton != null) {
                        rangeParams.x = overlayParams.x + dp(64); rangeParams.y = overlayParams.y;
                        windows.updateViewLayout(rangeButton, rangeParams);
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
                cancelLong();
                if (longTriggered) { longTriggered = false; return true; }
                if (dragging) { dragging = false; return true; }
                long now = SystemClock.uptimeMillis();
                if (now - lastTap < 320 && pendingSingle != null) {
                    cancelSingle(); lastTap = 0;
                    if (state == IDLE) openCaptureActivity(); else stopCapture(true);
                } else {
                    lastTap = now;
                    pendingSingle = () -> { pendingSingle = null; togglePause(); updateNotification(); updateOverlay(); };
                    handler.postDelayed(pendingSingle, 320);
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                cancelLong(); dragging = false; return true;
            default: return true;
        }
    }

    private void openCaptureActivity() {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("request_capture", true);
        try { startActivity(i); }
        catch (RuntimeException e) { showError("請點通知的「開始」完成錄屏授權"); updateNotification(); }
    }
    private void cancelLong() { if (pendingLong != null) { handler.removeCallbacks(pendingLong); pendingLong = null; } }
    private void cancelSingle() { if (pendingSingle != null) { handler.removeCallbacks(pendingSingle); pendingSingle = null; } }
    private void updateOverlay() { if (overlayText != null) overlayText.setText(state == IDLE ? "●" : state == PAUSED ? "▶" : "Ⅱ"); }
    private void removeOverlay() {
        cancelLong(); cancelSingle();
        closeRangeEditor();
        if (rangeButton != null) { try { windows.removeView(rangeButton); } catch (RuntimeException ignored) { } rangeButton = null; }
        if (overlay != null) { windows.removeView(overlay); overlay = null; overlayText = null; }
        overlayVisible = false;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private void showError(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }
    @Override public void onDestroy() { armed = false; removeOverlay(); stopCapture(true); super.onDestroy(); }
}

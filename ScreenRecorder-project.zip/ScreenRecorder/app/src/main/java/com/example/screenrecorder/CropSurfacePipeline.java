package com.example.screenrecorder;

import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.projection.MediaProjection;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** Draws a selected part of the projection into a video encoder surface. */
final class CropSurfacePipeline {
    private static final int EGL_RECORDABLE_ANDROID = 0x3142;
    private static final String VERTEX = "attribute vec2 aPosition; attribute vec2 aTex; varying vec2 vTex;"
        + "void main(){gl_Position=vec4(aPosition,0.0,1.0);vTex=aTex;}";
    private static final String FRAGMENT = "#extension GL_OES_EGL_image_external : require\n"
        + "precision mediump float; uniform samplerExternalOES uTexture; uniform mat4 uTexMatrix;"
        + "uniform vec4 uCrop; varying vec2 vTex;"
        + "void main(){vec2 uv=vec2(mix(uCrop.x,uCrop.z,vTex.x),mix(1.0-uCrop.w,1.0-uCrop.y,vTex.y));"
        + "vec4 p=uTexMatrix*vec4(uv,0.0,1.0);gl_FragColor=texture2D(uTexture,p.xy);}";
    private static final float[] QUAD = {
        -1f, -1f, 0f, 0f,
         1f, -1f, 1f, 0f,
        -1f,  1f, 0f, 1f,
         1f,  1f, 1f, 1f
    };
    private final Surface encoderSurface;
    private final int sourceWidth, sourceHeight, outputWidth, outputHeight;
    private final RectF crop;
    private final Consumer<String> failure;
    private HandlerThread thread;
    private Handler handler;
    private SurfaceTexture texture;
    private Surface inputSurface;
    private VirtualDisplay display;
    private EGLDisplay eglDisplay = EGL14.EGL_NO_DISPLAY;
    private EGLContext eglContext = EGL14.EGL_NO_CONTEXT;
    private EGLSurface eglSurface = EGL14.EGL_NO_SURFACE;
    private int textureId, program;
    private FloatBuffer quad;
    private final float[] textureMatrix = new float[16];
    private volatile boolean paused, closed;
    private volatile String initError;
    private long lastTimestamp;

    CropSurfacePipeline(Surface encoderSurface, int sourceWidth, int sourceHeight,
                        int outputWidth, int outputHeight, RectF crop, Consumer<String> failure) {
        this.encoderSurface = encoderSurface;
        this.sourceWidth = sourceWidth; this.sourceHeight = sourceHeight;
        this.outputWidth = outputWidth; this.outputHeight = outputHeight;
        this.crop = new RectF(crop); this.failure = failure;
    }

    void start(MediaProjection projection, int density) throws IOException {
        thread = new HandlerThread("screen-crop-gl"); thread.start();
        handler = new Handler(thread.getLooper());
        CountDownLatch ready = new CountDownLatch(1);
        handler.post(() -> {
            try { initializeGl(); }
            catch (Exception e) { initError = e.getClass().getSimpleName() + ": " + e.getMessage(); cleanupGl(); }
            finally { ready.countDown(); }
        });
        try {
            if (!ready.await(5, TimeUnit.SECONDS)) throw new IOException("裁切繪製器啟動逾時");
        } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException(e); }
        if (initError != null) { stop(); throw new IOException(initError); }
        try {
            display = projection.createVirtualDisplay("淡橘錄屏裁切", sourceWidth, sourceHeight, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, handler);
        } catch (RuntimeException e) { stop(); throw new IOException("無法建立裁切螢幕", e); }
    }

    void pause() { paused = true; }
    void resume() { paused = false; }

    void stop() {
        closed = true;
        if (display != null) { try { display.release(); } catch (RuntimeException ignored) { } display = null; }
        if (handler != null) {
            CountDownLatch done = new CountDownLatch(1);
            handler.post(() -> { cleanupGl(); done.countDown(); });
            try { done.await(3, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        if (thread != null) {
            thread.quitSafely();
            try { thread.join(3000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            thread = null; handler = null;
        }
    }

    private void initializeGl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) throw new IllegalStateException("EGL display unavailable");
        int[] versions = new int[2];
        if (!EGL14.eglInitialize(eglDisplay, versions, 0, versions, 1)) throw new IllegalStateException("EGL initialization failed");
        int[] attributes = {EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1, EGL14.EGL_NONE};
        EGLConfig[] configs = new EGLConfig[1]; int[] count = new int[1];
        if (!EGL14.eglChooseConfig(eglDisplay, attributes, 0, configs, 0, 1, count, 0) || count[0] == 0)
            throw new IllegalStateException("No recordable EGL config");
        int[] contextAttributes = {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
        eglContext = EGL14.eglCreateContext(eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT, contextAttributes, 0);
        if (eglContext == EGL14.EGL_NO_CONTEXT) throw new IllegalStateException("EGL context failed");
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0], encoderSurface, new int[]{EGL14.EGL_NONE}, 0);
        if (eglSurface == EGL14.EGL_NO_SURFACE || !EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext))
            throw new IllegalStateException("EGL encoder surface failed");

        int[] textures = new int[1]; GLES20.glGenTextures(1, textures, 0); textureId = textures[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        program = linkProgram(VERTEX, FRAGMENT);
        quad = ByteBuffer.allocateDirect(QUAD.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        quad.put(QUAD).position(0);
        texture = new SurfaceTexture(textureId);
        texture.setDefaultBufferSize(sourceWidth, sourceHeight);
        inputSurface = new Surface(texture);
        texture.setOnFrameAvailableListener(ignored -> {
            if (closed) return;
            try { drawFrame(); }
            catch (RuntimeException e) { closed = true; failure.accept("裁切畫面失敗：" + e.getClass().getSimpleName()); }
        }, handler);
    }

    private void drawFrame() {
        texture.updateTexImage();
        if (paused) return;
        texture.getTransformMatrix(textureMatrix);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        GLES20.glUseProgram(program);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
        int pos = GLES20.glGetAttribLocation(program, "aPosition");
        int tex = GLES20.glGetAttribLocation(program, "aTex");
        quad.position(0); GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 16, quad);
        quad.position(2); GLES20.glVertexAttribPointer(tex, 2, GLES20.GL_FLOAT, false, 16, quad);
        GLES20.glEnableVertexAttribArray(pos); GLES20.glEnableVertexAttribArray(tex);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uTexture"), 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program, "uTexMatrix"), 1, false, textureMatrix, 0);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(program, "uCrop"), crop.left, crop.top, crop.right, crop.bottom);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        long timestamp = Math.max(lastTimestamp + 1, texture.getTimestamp());
        lastTimestamp = timestamp;
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, timestamp);
        if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) throw new IllegalStateException("EGL swap failed");
    }

    private static int compileShader(int type, String source) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, source); GLES20.glCompileShader(shader);
        int[] status = new int[1]; GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0);
        if (status[0] == 0) {
            String log = GLES20.glGetShaderInfoLog(shader); GLES20.glDeleteShader(shader);
            throw new IllegalStateException(log);
        }
        return shader;
    }
    private static int linkProgram(String vertex, String fragment) {
        int v = compileShader(GLES20.GL_VERTEX_SHADER, vertex);
        int f = compileShader(GLES20.GL_FRAGMENT_SHADER, fragment);
        int program = GLES20.glCreateProgram(); GLES20.glAttachShader(program, v); GLES20.glAttachShader(program, f);
        GLES20.glLinkProgram(program); GLES20.glDeleteShader(v); GLES20.glDeleteShader(f);
        int[] status = new int[1]; GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, status, 0);
        if (status[0] == 0) {
            String log = GLES20.glGetProgramInfoLog(program); GLES20.glDeleteProgram(program);
            throw new IllegalStateException(log);
        }
        return program;
    }

    private void cleanupGl() {
        if (texture != null) { texture.setOnFrameAvailableListener(null); texture.release(); texture = null; }
        if (inputSurface != null) { inputSurface.release(); inputSurface = null; }
        if (program != 0) { GLES20.glDeleteProgram(program); program = 0; }
        if (textureId != 0) { GLES20.glDeleteTextures(1, new int[]{textureId}, 0); textureId = 0; }
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface);
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext);
            EGL14.eglTerminate(eglDisplay);
            eglDisplay = EGL14.EGL_NO_DISPLAY; eglSurface = EGL14.EGL_NO_SURFACE; eglContext = EGL14.EGL_NO_CONTEXT;
        }
    }
}
